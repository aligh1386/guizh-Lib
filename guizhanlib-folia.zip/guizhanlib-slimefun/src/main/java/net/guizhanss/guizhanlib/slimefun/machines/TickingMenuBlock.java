package net.guizhanss.guizhanlib.slimefun.machines;

import io.github.thebusybiscuit.slimefun4.api.items.ItemGroup;
import io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem;
import io.github.thebusybiscuit.slimefun4.api.items.SlimefunItemStack;
import io.github.thebusybiscuit.slimefun4.api.recipes.RecipeType;
import lombok.Getter;
import me.mrCookieSlime.CSCoreLibPlugin.Configuration.Config;
import me.mrCookieSlime.Slimefun.Objects.handlers.BlockTicker;
import me.mrCookieSlime.Slimefun.api.BlockStorage;
import me.mrCookieSlime.Slimefun.api.inventory.BlockMenu;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;

import javax.annotation.ParametersAreNonnullByDefault;

/**
 * A {@link TickingMenuBlock} is a {@link MenuBlock} with {@link BlockTicker}.
 * <p>
 * Modified from InfinityLib
 *
 * @author Mooy1
 * @author ybw0014
 */
@ParametersAreNonnullByDefault
public abstract class TickingMenuBlock extends MenuBlock {

    /**
     * The elapsed Slimefun ticks since the instance was created.
     */
    @Getter
    private int tickCount = 0;

    @ParametersAreNonnullByDefault
    protected TickingMenuBlock(ItemGroup itemGroup, SlimefunItemStack item, RecipeType recipeType, ItemStack[] recipe) {
        super(itemGroup, item, recipeType, recipe);

        addItemHandler(new BlockTicker() {
            @Override
            public boolean isSynchronized() {
                return isSync();
            }

            @Override
            @ParametersAreNonnullByDefault
            public void tick(Block b, SlimefunItem item, Config data) {
                BlockMenu menu = BlockStorage.getInventory(b);
                if (menu != null) {
                    TickingMenuBlock.this.tick(b, menu);
                }
            }

            @Override
            public void uniqueTick() {
                TickingMenuBlock.this.tickCount++;
                TickingMenuBlock.this.uniqueTick();
            }
        });
    }

    @ParametersAreNonnullByDefault
    protected abstract void tick(Block b, BlockMenu menu);

    protected void uniqueTick() {
    }

    protected boolean isSync() {
        return false;
    }
}
